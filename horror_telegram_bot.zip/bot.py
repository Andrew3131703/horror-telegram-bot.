import random
import os
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)
import requests

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
GEN_API_URL = os.getenv("VIDEO_API_URL")
GEN_API_KEY = os.getenv("VIDEO_API_KEY")

scary_phrases = [
    "Она всё ещё смотрит на тебя...",
    "Он идёт по ту сторону экрана.",
    "Ты слышал это?",
    "Кто‑то сейчас за твоей спиной.",
    "Твои глаза не шевелятся, а ведь должны...",
    "Оно видит тебя.",
]

templates = {
    "under_bed": "ребёнок под кроватью по ночам",
    "mirror": "демон в зеркале",
    "tv": "из телевизора выходит лицо",
    "forest": "одинокий человек идёт по тёмному лесу",
    "shower": "силуэт в душе",
    "corridor": "длинный пустой коридор с шагами",
}

def generate_video(prompt: str) -> str:
    if not GEN_API_URL or not GEN_API_KEY:
        return "https://example.com/fake_horror_video.mp4"

    resp = requests.post(
        GEN_API_URL,
        headers={"Authorization": f"Bearer {GEN_API_KEY}"},
        json={"prompt": prompt}
    )
    data = resp.json()
    return data.get("url")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = [
        [InlineKeyboardButton("Под кроватью 👁", callback_data="under_bed")],
        [InlineKeyboardButton("В зеркале 🪞", callback_data="mirror")],
        [InlineKeyboardButton("Из телевизора 📺", callback_data="tv")],
        [InlineKeyboardButton("В лесу 🌲", callback_data="forest")],
        [InlineKeyboardButton("В душе 🚿", callback_data="shower")],
        [InlineKeyboardButton("В коридоре 👣", callback_data="corridor")],
    ]
    await update.message.reply_text(
        "👁 Привет... Я покажу тебе настоящий страх.\nВыбери шаблон или напиши свой промт:",
        reply_markup=InlineKeyboardMarkup(kb)
    )

async def on_template(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    key = query.data
    prompt = templates.get(key, "страшная сцена ночью")
    await query.message.reply_text(f"Генерирую: *{prompt}*...", parse_mode="Markdown")
    url = generate_video(prompt)
    phrase = random.choice(scary_phrases)
    await query.message.reply_video(video=url, caption=f"💀 {phrase}")

async def on_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    prompt = update.message.text
    await update.message.reply_text("🧠 Думаю... создаю ужас...")
    url = generate_video(prompt)
    phrase = random.choice(scary_phrases)
    await update.message.reply_video(video=url, caption=f"🎥 {prompt}\n\n💀 {phrase}")

async def scream(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Boo! 👻")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("scream", scream))
    app.add_handler(CallbackQueryHandler(on_template))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_prompt))
    print("Бот запущен!")
    app.run_polling()

if __name__ == "__main__":
    main()